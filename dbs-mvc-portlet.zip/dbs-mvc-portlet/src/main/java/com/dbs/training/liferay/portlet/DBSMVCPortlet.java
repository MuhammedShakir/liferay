package com.dbs.training.liferay.portlet;

import com.dbs.training.liferay.constants.DBSMVCPortletKeys;
import com.dbs.training.liferay.portlet.model.DemoCustomer;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletConfig;
import javax.portlet.PortletContext;
import javax.portlet.PortletException;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;

import org.osgi.service.component.annotations.Component;

/**
 * @author muhammedshakir
 */
@Component(immediate = true, property = { 
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=false",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + DBSMVCPortletKeys.DBSMVC,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user" },

	service = Portlet.class)

public class DBSMVCPortlet extends MVCPortlet {
	
	
	private static List<DemoCustomer> customers = new ArrayList<>();

	PortletContext portletContext = null;

	@Override
	public void init(PortletConfig config) throws PortletException {

		this.portletContext = config.getPortletContext();
		super.init(config);
	}

	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {

		String view = ParamUtil.getString(renderRequest, "view", "default");

		if ("add-customer-view".equalsIgnoreCase(view)) {

			PortletRequestDispatcher dispatcher = portletContext.getRequestDispatcher("/add_customer.jsp");
			dispatcher.forward(renderRequest, renderResponse);
			return;
		} else {
			
			renderRequest.setAttribute("customer-list", customers);
			super.render(renderRequest, renderResponse);
		}
	

	}

	@Override
	public void processAction(ActionRequest actionRequest, ActionResponse actionResponse)
			throws IOException, PortletException {
		// TODO Auto-generated method stub

		
		long customerId = ParamUtil.getLong(actionRequest, "customerId", 0);
		String name = ParamUtil.getString(actionRequest, "name", "default");
		String address = ParamUtil.getString(actionRequest, "address");
		
		
		
		DemoCustomer customer =new DemoCustomer(customerId, name, address);
		customers.add(customer);
		
		PortletSession portletSession = actionRequest.getPortletSession();
		portletSession.setAttribute("last-added-customer", customer, PortletSession.APPLICATION_SCOPE);
		
		
		actionResponse.setWindowState(WindowState.MAXIMIZED);
		//super.processAction(actionRequest, actionResponse);
	}

	@Override
	public void destroy() {

		System.out.println("In destroy....");

		super.destroy();
	}

}
