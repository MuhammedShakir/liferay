create table dbs_Customer (
	uuid_ VARCHAR(75) null,
	customerId LONG not null primary key,
	name VARCHAR(75) null,
	address VARCHAR(75) null
);