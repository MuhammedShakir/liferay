/**
 * Copyright 2000-present Liferay, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.dbs.training.liferay.portlet;

import javax.portlet.Portlet;

import com.dbs.training.liferay.portlet.model.DemoCustomer;
import com.liferay.portal.kernel.util.SessionParamUtil;

import java.io.IOException;
import java.io.PrintWriter;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import org.osgi.service.component.annotations.Component;

@Component(immediate = true, property = { "com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true", "javax.portlet.security-role-ref=power-user,user",
		"javax.portlet.display-name=New Portlet" }, service = Portlet.class)
public class NewPortlet extends GenericPortlet {

	@Override
	protected void doView(RenderRequest request, RenderResponse response) throws IOException, PortletException {

		PrintWriter printWriter = response.getWriter();

		PortletSession portletSession = request.getPortletSession();

		DemoCustomer c = new DemoCustomer(0, "Default", "Default");
		if (portletSession.getAttribute("last-added-customer", PortletSession.APPLICATION_SCOPE) != null) {
			c = (DemoCustomer) portletSession.getAttribute("last-added-customer", PortletSession.APPLICATION_SCOPE);
		}

		printWriter.print(
				"The last added customer is : " + c.getCustomerId() + " -- " + c.getName() + " -- " + c.getAddress());
	}

}