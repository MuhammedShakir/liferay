package com.dbs.training.liferay.portlet.model;

public class DemoCustomer {

	private long customerId;
	private String name;
	private String address;

	public DemoCustomer(long id, String name, String address) {
		this.customerId = id;
		this.name = name;
		this.address = address;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
