package com.dbs.training.liferay.constants;

/**
 * @author muhammedshakir
 */
public class DBSMVCPortletKeys {

	public static final String DBSMVC = "dbsmvc";

}